# GraphQL-Lambda-API
Allow us to query Subreddits
Use existing APIs and integrate them easily with GraphQL. We will build a GraphQL application that will allow us to query Subreddits and display its posts.
